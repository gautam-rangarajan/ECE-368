int * Longest_conserved_gene_sequence (char * filename, int  * size_of_seq);
